# infeneon_g10_chess
Chess Board Design
